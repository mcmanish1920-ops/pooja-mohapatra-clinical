# Pooja Mohapatra — Premium Clinical Psychology Website

Open `index.html` in a browser.

## Customize
Edit `config.js` to change:
- name/title
- biography and credentials
- hero image
- logo
- services
- FAQ
- phone/email/address
- booking/WhatsApp links
- social links
- brand colours

Replace `assets/hero.jpg` and `assets/logo.png` whenever you want new artwork. The paths can also be changed in `config.js`.

Important: replace all bracketed placeholder professional/registration/contact information with verified details before publishing.
